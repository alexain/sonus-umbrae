# Third-party notices

## Ghost Note Audio CloudSeedCore

The Sonus Umbrae `sky` reverb uses the CloudSeedCore reverb algorithm by **Ghost Note Audio / Ghost Note Engineering Ltd**, distributed under the MIT License. Upstream license notice: **Copyright (c) 2024 Ghost Note Audio**.

Upstream: https://github.com/GhostNoteAudio/CloudSeedCore

Ghost Note Audio is the original author of the CloudSeedCore code used by this backend. The upstream project permits free and commercial use and requests attribution to Ghost Note Audio. Sonus Umbrae exposes the algorithm under the model name `sky`. Sonus Umbrae is an independent project and is **not created by, sponsored by, or affiliated with Ghost Note Audio**. Any reference to “Cloud Seed” in project documentation refers to the upstream algorithm and must not imply otherwise.

## Electrosmith DaisySP

The Sonus Umbrae basic oscillator VOICE backend and `svf` filter backend use DaisySP code by **Electrosmith, Corp.**, distributed under the MIT License.

Upstream: https://github.com/electro-smith/DaisySP

The current `daisy-oscillators.wasm` build uses DaisySP's oscillator implementation for `sine`, `triangle`, `sawtooth`, `ramp`, and `square` VOICE sounds. `daisy-filters.wasm` uses DaisySP's double-sampled stable state-variable filter implementation; Sonus exposes its low-pass, high-pass, band-pass and notch responses as `lp`, `hp`, `bp` and `np`.

## Mutable Instruments STM32F DSP

Selected Sonus synthesis and modulation engines are derived from MIT-licensed STM32F DSP code by **Emilie Gillet / Mutable Instruments**, including DSP from Plaits, Elements, Rings and Tides 2018.

Upstream: https://github.com/pichenettes/eurorack

Mutable Instruments is a registered trademark. Sonus Umbrae is independent and is not affiliated with or endorsed by Mutable Instruments.

## SuperParasites

The `mist.*` FX family uses MIT-licensed STM32F DSP from **Patrick Dowling's SuperParasites** project and its permissively licensed upstream lineage.

Upstream: https://github.com/patrickdowling/superparasites

## DSPark

The creative delay uses DSPark by Cristian Moresi as its forward delay DSP core. DSPark is distributed under the MIT License. The build setup fetches the upstream v1.7.0 source from https://github.com/CristianMoresi/DSPark. Sonus Umbrae adds its own multi-line routing and reverse-window processing layer around that core.

## Mutable Instruments Marbles random-voltage core

Sonus Umbrae uses selected MIT-licensed Marbles random-voltage and lag-processing components by **Emilie Gillet / Mutable Instruments** for the `MOD dices` backend.

Upstream: https://github.com/pichenettes/eurorack  
Utility library: https://github.com/pichenettes/stmlib

The Sonus integration intentionally omits Marbles' T/gate section and internal musical quantizer. Sonus Umbrae supplies its own timing, routing, language, visualization and macro-control layer and exposes the integration under the independent model name `dices`.

Mutable Instruments is a registered trademark. Sonus Umbrae is independent and is not affiliated with or endorsed by Mutable Instruments.

## 606-Inspired-Synth-Drums
Sonus Umbrae uses the header-only **606-Inspired-Synth-Drums** DSP by Matthew Fecher / AudioKit Pro for the experimental `sonus606` synthesis backend.

Upstream: https://github.com/analogcode/606-Inspired-Synth-Drums
License: MIT

Sonus supplies its own WASM bridge, stereo mixing, scheduling, language and visualization layers.
